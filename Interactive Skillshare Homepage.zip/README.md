
  # Interactive Skillshare Homepage

  This is a code bundle for Interactive Skillshare Homepage. The original project is available at https://www.figma.com/design/CyunwiNsPaF8Ymqx2op43k/Interactive-Skillshare-Homepage.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  