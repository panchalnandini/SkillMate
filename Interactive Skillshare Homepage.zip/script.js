// Mock Data
const profiles = [
    {
        id: 1,
        name: "Sarah Johnson",
        age: 24,
        location: "San Francisco, CA",
        skills: ["React", "TypeScript", "UI Design"],
        learningGoals: ["Backend Development", "Python", "Data Science"],
        bio: "Frontend developer looking to expand into full-stack. Love building beautiful interfaces!",
        image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=500&fit=crop",
        completedCourses: 12,
        level: "Intermediate"
    },
    {
        id: 2,
        name: "Marcus Chen",
        age: 28,
        location: "New York, NY",
        skills: ["Python", "Machine Learning", "Data Analysis"],
        learningGoals: ["Web Development", "React", "TypeScript"],
        bio: "Data scientist eager to learn web development to build ML applications.",
        image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=500&fit=crop",
        completedCourses: 18,
        level: "Advanced"
    },
    {
        id: 3,
        name: "Emily Rodriguez",
        age: 22,
        location: "Austin, TX",
        skills: ["UX Design", "Figma", "Adobe XD"],
        learningGoals: ["Frontend Development", "CSS", "Animation"],
        bio: "Designer wanting to code my own designs. Passionate about user experience!",
        image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=500&fit=crop",
        completedCourses: 8,
        level: "Beginner"
    },
    {
        id: 4,
        name: "Alex Kumar",
        age: 26,
        location: "Seattle, WA",
        skills: ["Node.js", "MongoDB", "Express"],
        learningGoals: ["DevOps", "AWS", "Docker"],
        bio: "Backend engineer looking to master cloud infrastructure and deployment.",
        image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=500&fit=crop",
        completedCourses: 15,
        level: "Intermediate"
    },
    {
        id: 5,
        name: "Jessica Park",
        age: 25,
        location: "Boston, MA",
        skills: ["Digital Marketing", "SEO", "Content Strategy"],
        learningGoals: ["Web Analytics", "Python", "Automation"],
        bio: "Marketing professional learning to automate workflows and analyze data.",
        image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=500&fit=crop",
        completedCourses: 10,
        level: "Intermediate"
    }
];

const skillsProgress = [
    { name: "React Development", progress: 75, xp: 7500, totalXp: 10000 },
    { name: "Python Programming", progress: 45, xp: 4500, totalXp: 10000 },
    { name: "UI/UX Design", progress: 60, xp: 6000, totalXp: 10000 },
    { name: "Data Science", progress: 30, xp: 3000, totalXp: 10000 }
];

const achievements = [
    { name: "Fast Learner", description: "Complete 5 courses in a week", earned: true },
    { name: "Community Helper", description: "Help 10 peers", earned: true },
    { name: "Streak Master", description: "7-day learning streak", earned: true },
    { name: "Skill Expert", description: "Master 3 skills", earned: false }
];

const recentActivity = [
    { course: "Advanced React Patterns", progress: 85, date: "Today" },
    { course: "Python for Data Analysis", progress: 40, date: "Yesterday" },
    { course: "Figma Masterclass", progress: 65, date: "2 days ago" }
];

const contacts = [
    {
        id: 1,
        name: "Sarah Johnson",
        avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
        lastMessage: "Sure! Let's meet at 3 PM tomorrow",
        timestamp: "2m ago",
        unread: 2,
        online: true
    },
    {
        id: 2,
        name: "Marcus Chen",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
        lastMessage: "Thanks for the Python tutorial!",
        timestamp: "1h ago",
        unread: 0,
        online: true
    },
    {
        id: 3,
        name: "Emily Rodriguez",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
        lastMessage: "Can you review my design?",
        timestamp: "3h ago",
        unread: 1,
        online: false
    },
    {
        id: 4,
        name: "Study Group: React Masters",
        avatar: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=100&h=100&fit=crop",
        lastMessage: "Alex: Great session today!",
        timestamp: "5h ago",
        unread: 5,
        online: false
    }
];

const messages = [
    {
        sender: "Sarah Johnson",
        content: "Hey! I saw your profile and noticed we're both learning React. Want to collaborate on a project?",
        timestamp: "10:30 AM",
        isMe: false
    },
    {
        sender: "Me",
        content: "Hi Sarah! That sounds great! I'm actually working on a portfolio site right now.",
        timestamp: "10:32 AM",
        isMe: true
    },
    {
        sender: "Sarah Johnson",
        content: "Perfect! I'm trying to build a task management app. Maybe we can help each other?",
        timestamp: "10:35 AM",
        isMe: false
    },
    {
        sender: "Me",
        content: "Absolutely! When would you like to meet?",
        timestamp: "10:36 AM",
        isMe: true
    },
    {
        sender: "Sarah Johnson",
        content: "Sure! Let's meet at 3 PM tomorrow",
        timestamp: "10:38 AM",
        isMe: false
    }
];

const meetings = [
    {
        id: 1,
        title: "React Study Session with Sarah",
        date: 11,
        time: "15:00",
        duration: "1 hour",
        type: "video",
        attendees: ["Sarah Johnson"],
        color: "blue"
    },
    {
        id: 2,
        title: "Python Workshop",
        date: 12,
        time: "14:00",
        duration: "2 hours",
        type: "video",
        attendees: ["Marcus Chen", "Emily Rodriguez"],
        color: "green"
    },
    {
        id: 3,
        title: "Design Review",
        date: 13,
        time: "10:00",
        duration: "30 min",
        type: "video",
        attendees: ["Emily Rodriguez"],
        color: "purple"
    },
    {
        id: 4,
        title: "Community Meetup",
        date: 15,
        time: "18:00",
        duration: "2 hours",
        type: "inPerson",
        attendees: ["Study Group"],
        location: "Coffee House, Main St",
        color: "orange"
    }
];

const topPerformers = [
    {
        rank: 1,
        name: "Alex Kumar",
        avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
        xp: 45000,
        coursesCompleted: 25,
        streak: 30
    },
    {
        rank: 2,
        name: "Sarah Johnson",
        avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
        xp: 42000,
        coursesCompleted: 23,
        streak: 28
    },
    {
        rank: 3,
        name: "Marcus Chen",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
        xp: 38000,
        coursesCompleted: 21,
        streak: 25
    },
    {
        rank: 4,
        name: "Emily Rodriguez",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
        xp: 35000,
        coursesCompleted: 19,
        streak: 22
    },
    {
        rank: 5,
        name: "Jessica Park",
        avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop",
        xp: 32000,
        coursesCompleted: 18,
        streak: 20
    }
];

const topContributors = [
    {
        name: "David Lee",
        avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop",
        contributions: 127,
        type: "Helpful Answers",
        badge: "Expert Helper"
    },
    {
        name: "Lisa Wang",
        avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop",
        contributions: 98,
        type: "Resources Shared",
        badge: "Resource Master"
    },
    {
        name: "James Miller",
        avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100&h=100&fit=crop",
        contributions: 85,
        type: "Helpful Answers",
        badge: "Community Star"
    }
];

const discussions = [
    {
        title: "Best practices for React state management?",
        author: "Sarah Johnson",
        replies: 24,
        likes: 45,
        category: "React",
        time: "2h ago"
    },
    {
        title: "Python vs JavaScript for beginners",
        author: "Marcus Chen",
        replies: 18,
        likes: 32,
        category: "General",
        time: "5h ago"
    },
    {
        title: "How to design better user interfaces?",
        author: "Emily Rodriguez",
        replies: 15,
        likes: 28,
        category: "Design",
        time: "1d ago"
    }
];

const trendingSkills = [
    {
        name: "Artificial Intelligence & Machine Learning",
        category: "Technology",
        growth: 245,
        demand: "Very High",
        avgSalary: "$120k - $180k",
        learners: 125000,
        courses: 342,
        description: "AI and ML continue to dominate as companies integrate intelligent systems.",
        trending: true
    },
    {
        name: "Cloud Computing (AWS, Azure, GCP)",
        category: "Technology",
        growth: 198,
        demand: "Very High",
        avgSalary: "$110k - $160k",
        learners: 98000,
        courses: 287,
        description: "Cloud infrastructure skills are essential for modern software development.",
        trending: true
    },
    {
        name: "Cybersecurity",
        category: "Technology",
        growth: 187,
        demand: "Very High",
        avgSalary: "$100k - $150k",
        learners: 87000,
        courses: 234,
        description: "Growing threats drive massive demand for security professionals.",
        trending: true
    },
    {
        name: "Data Science & Analytics",
        category: "Technology",
        growth: 165,
        demand: "High",
        avgSalary: "$95k - $145k",
        learners: 112000,
        courses: 398,
        description: "Data-driven decision making is crucial across all industries.",
        trending: false
    },
    {
        name: "Full-Stack Development",
        category: "Technology",
        growth: 142,
        demand: "High",
        avgSalary: "$90k - $140k",
        learners: 156000,
        courses: 512,
        description: "Versatile developers who can handle both frontend and backend are in high demand.",
        trending: false
    }
];

// State Management
let currentProfileIndex = 0;
let currentSection = 'home';
let selectedDate = 11;

// Navigation
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    setupNavigation();
    setupMobileMenu();
    initializeMatchmaking();
    initializeDashboard();
    initializeChat();
    initializeCalendar();
    initializeCommunity();
    initializeTrendingSkills();
}

function setupNavigation() {
    const navButtons = document.querySelectorAll('.nav-btn');
    
    navButtons.forEach(button => {
        button.addEventListener('click', function() {
            const section = this.getAttribute('data-section');
            switchSection(section);
            
            // Update active state
            navButtons.forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll(`.nav-btn[data-section="${section}"]`).forEach(btn => {
                btn.classList.add('active');
            });
            
            // Close mobile menu if open
            document.getElementById('mobileMenu').classList.remove('active');
        });
    });
}

function setupMobileMenu() {
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const mobileMenu = document.getElementById('mobileMenu');
    
    mobileMenuBtn.addEventListener('click', function() {
        mobileMenu.classList.toggle('active');
        const icon = this.querySelector('i');
        icon.classList.toggle('fa-bars');
        icon.classList.toggle('fa-times');
    });
}

function switchSection(section) {
    currentSection = section;
    
    // Hide all sections
    document.querySelectorAll('.section').forEach(sec => {
        sec.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(section).classList.add('active');
}

// Matchmaking
function initializeMatchmaking() {
    renderProfileCard();
    
    document.getElementById('skipBtn').addEventListener('click', () => swipeCard('left'));
    document.getElementById('likeBtn').addEventListener('click', () => swipeCard('right'));
}

function renderProfileCard() {
    const cardStack = document.getElementById('cardStack');
    const profile = profiles[currentProfileIndex];
    
    if (!profile) {
        currentProfileIndex = 0;
        renderProfileCard();
        return;
    }
    
    const card = document.createElement('div');
    card.className = 'profile-card';
    card.innerHTML = `
        <div style="position: relative;">
            <img src="${profile.image}" alt="${profile.name}" class="profile-image">
            <span class="profile-badge">${profile.level}</span>
        </div>
        <div class="profile-content">
            <div class="profile-header">
                <h3 class="profile-name">${profile.name}, ${profile.age}</h3>
                <div class="profile-location">
                    <i class="fas fa-map-marker-alt"></i>
                    ${profile.location}
                </div>
            </div>
            <p class="profile-bio">${profile.bio}</p>
            <div class="profile-section">
                <div class="profile-section-header">
                    <i class="fas fa-briefcase"></i>
                    <span>Current Skills</span>
                </div>
                <div class="tags">
                    ${profile.skills.map(skill => `<span class="tag">${skill}</span>`).join('')}
                </div>
            </div>
            <div class="profile-section">
                <div class="profile-section-header">
                    <i class="fas fa-award"></i>
                    <span>Learning Goals</span>
                </div>
                <div class="tags">
                    ${profile.learningGoals.map(goal => `<span class="tag outline">${goal}</span>`).join('')}
                </div>
            </div>
            <div class="profile-stats">
                ${profile.completedCourses} courses completed
            </div>
        </div>
    `;
    
    cardStack.innerHTML = '';
    cardStack.appendChild(card);
    
    updateProfileCounter();
}

function swipeCard(direction) {
    const card = document.querySelector('.profile-card');
    if (!card) return;
    
    card.classList.add(`swipe-${direction}`);
    
    setTimeout(() => {
        currentProfileIndex = (currentProfileIndex + 1) % profiles.length;
        renderProfileCard();
    }, 300);
}

function updateProfileCounter() {
    const counter = document.getElementById('profileCounter');
    counter.textContent = `Profile ${currentProfileIndex + 1} of ${profiles.length}`;
}

// Dashboard
function initializeDashboard() {
    renderSkillsProgress();
    renderRecentActivity();
    renderAchievements();
}

function renderSkillsProgress() {
    const container = document.getElementById('skillsProgress');
    container.innerHTML = skillsProgress.map(skill => `
        <div class="skill-item">
            <div class="skill-header">
                <span>${skill.name}</span>
                <span class="skill-xp">${skill.xp.toLocaleString()} / ${skill.totalXp.toLocaleString()} XP</span>
            </div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${skill.progress}%"></div>
            </div>
            <div class="skill-percent">${skill.progress}% Complete</div>
        </div>
    `).join('');
}

function renderRecentActivity() {
    const container = document.getElementById('recentActivity');
    container.innerHTML = recentActivity.map(activity => `
        <div class="activity-item">
            <div class="activity-info">
                <div class="activity-name">${activity.course}</div>
                <div class="activity-progress">
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${activity.progress}%"></div>
                    </div>
                    <span class="activity-percent">${activity.progress}%</span>
                </div>
            </div>
            <span class="activity-date">${activity.date}</span>
        </div>
    `).join('');
}

function renderAchievements() {
    const container = document.getElementById('achievements');
    container.innerHTML = achievements.map(achievement => `
        <div class="achievement-item ${achievement.earned ? 'earned' : 'locked'}">
            <i class="fas fa-award achievement-icon ${achievement.earned ? 'earned' : 'locked'}"></i>
            <div class="achievement-content">
                <div class="achievement-name">${achievement.name}</div>
                <div class="achievement-desc">${achievement.description}</div>
            </div>
            ${achievement.earned ? '<span class="badge">Earned</span>' : ''}
        </div>
    `).join('');
}

// Chat
function initializeChat() {
    renderContacts();
    renderMessages();
    
    document.getElementById('sendBtn').addEventListener('click', sendMessage);
    document.getElementById('messageInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') sendMessage();
    });
}

function renderContacts() {
    const container = document.getElementById('contactsList');
    container.innerHTML = contacts.map((contact, index) => `
        <div class="contact-item ${index === 0 ? 'active' : ''}">
            <div class="contact-avatar-container">
                <img src="${contact.avatar}" alt="${contact.name}" class="contact-avatar">
                ${contact.online ? '<div class="online-indicator"></div>' : ''}
            </div>
            <div class="contact-info">
                <div class="contact-header">
                    <span class="contact-name">${contact.name}</span>
                    <span class="contact-time">${contact.timestamp}</span>
                </div>
                <div class="contact-message">${contact.lastMessage}</div>
            </div>
            ${contact.unread > 0 ? `<span class="unread-badge">${contact.unread}</span>` : ''}
        </div>
    `).join('');
}

function renderMessages() {
    const container = document.getElementById('messagesContainer');
    container.innerHTML = messages.map(message => `
        <div class="message ${message.isMe ? 'sent' : 'received'}">
            <div class="message-content">
                ${!message.isMe ? `<div class="message-sender">${message.sender}</div>` : ''}
                <div class="message-text">${message.content}</div>
                <div class="message-time">${message.timestamp}</div>
            </div>
        </div>
    `).join('');
    
    container.scrollTop = container.scrollHeight;
}

function sendMessage() {
    const input = document.getElementById('messageInput');
    const text = input.value.trim();
    
    if (text) {
        const now = new Date();
        const timestamp = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        messages.push({
            sender: "Me",
            content: text,
            timestamp: timestamp,
            isMe: true
        });
        
        renderMessages();
        input.value = '';
    }
}

// Calendar
function initializeCalendar() {
    renderCalendar();
    renderMeetingsList();
    renderUpcomingMeetings();
}

function renderCalendar() {
    const container = document.getElementById('calendarView');
    const daysInMonth = 31;
    const firstDayOfMonth = 3; // Wednesday
    
    let html = '<div class="calendar-weekdays">';
    ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].forEach(day => {
        html += `<div class="calendar-weekday">${day}</div>`;
    });
    html += '</div><div class="calendar-days">';
    
    // Empty cells before first day
    for (let i = 0; i < firstDayOfMonth; i++) {
        html += '<div class="calendar-day empty"></div>';
    }
    
    // Days of month
    for (let day = 1; day <= daysInMonth; day++) {
        const dayMeetings = meetings.filter(m => m.date === day);
        const isToday = day === 10;
        const isSelected = day === selectedDate;
        
        html += `
            <div class="calendar-day ${isToday ? 'today' : ''} ${isSelected ? 'selected' : ''}" 
                 onclick="selectDate(${day})">
                <div class="calendar-day-number">${day}</div>
                ${dayMeetings.length > 0 ? `
                    <div class="calendar-dots">
                        ${dayMeetings.slice(0, 3).map(m => `<div class="calendar-dot" style="background: ${getColorHex(m.color)}"></div>`).join('')}
                    </div>
                ` : ''}
            </div>
        `;
    }
    
    html += '</div>';
    container.innerHTML = html;
}

function selectDate(day) {
    selectedDate = day;
    renderCalendar();
    renderMeetingsList();
    document.getElementById('selectedDay').textContent = day;
}

function renderMeetingsList() {
    const container = document.getElementById('meetingsList');
    const dayMeetings = meetings.filter(m => m.date === selectedDate);
    
    if (dayMeetings.length === 0) {
        container.innerHTML = '<div style="text-align: center; padding: 2rem; color: #9ca3af;">No meetings scheduled</div>';
        return;
    }
    
    container.innerHTML = dayMeetings.map(meeting => `
        <div class="meeting-item">
            <div class="meeting-header">
                <h4 class="meeting-title">${meeting.title}</h4>
                <span class="meeting-badge ${meeting.color}">${meeting.type === 'video' ? 'Video' : 'In Person'}</span>
            </div>
            <div class="meeting-details">
                <i class="fas fa-clock"></i>
                ${meeting.time} • ${meeting.duration}
            </div>
            <div class="meeting-details">
                <i class="fas fa-users"></i>
                ${meeting.attendees.join(', ')}
            </div>
            <div class="meeting-details">
                <i class="fas fa-${meeting.type === 'video' ? 'video' : 'map-marker-alt'}"></i>
                ${meeting.type === 'video' ? 'Video Call' : meeting.location}
            </div>
            <div class="meeting-actions">
                <button class="btn-primary">Join Meeting</button>
                <button class="btn-outline">Reschedule</button>
            </div>
        </div>
    `).join('');
}

function renderUpcomingMeetings() {
    const container = document.getElementById('upcomingMeetings');
    container.innerHTML = meetings.map(meeting => `
        <div class="upcoming-meeting-card ${meeting.color}">
            <p class="upcoming-meeting-title">${meeting.title}</p>
            <div class="upcoming-meeting-details">
                <p>Jan ${meeting.date}</p>
                <p>${meeting.time} • ${meeting.duration}</p>
                <p>
                    <i class="fas fa-${meeting.type === 'video' ? 'video' : 'map-marker-alt'}"></i>
                    ${meeting.type === 'video' ? 'Video Call' : 'In Person'}
                </p>
            </div>
        </div>
    `).join('');
}

function getColorHex(color) {
    const colors = {
        blue: '#3b82f6',
        green: '#10b981',
        purple: '#a855f7',
        orange: '#f97316'
    };
    return colors[color] || '#3b82f6';
}

// Community
function initializeCommunity() {
    renderTopPerformers();
    renderContributors();
    renderDiscussions();
}

function renderTopPerformers() {
    const gridContainer = document.getElementById('topPerformersGrid');
    const othersContainer = document.getElementById('otherPerformers');
    
    // Top 3
    const top3 = topPerformers.slice(0, 3);
    gridContainer.innerHTML = top3.map(performer => {
        const rankClass = performer.rank === 1 ? 'gold' : performer.rank === 2 ? 'silver' : 'bronze';
        return `
            <div class="performer-card ${rankClass}">
                <div class="performer-avatar-container">
                    <img src="${performer.avatar}" alt="${performer.name}" class="performer-avatar">
                    <div class="performer-rank ${rankClass}">
                        <i class="fas fa-${performer.rank === 1 ? 'trophy' : 'medal'}"></i>
                    </div>
                </div>
                <h4 class="performer-name">${performer.name}</h4>
                <div class="performer-stats">
                    <div class="performer-stat">
                        <span class="performer-stat-label">Total XP:</span>
                        <span class="performer-stat-value">${performer.xp.toLocaleString()}</span>
                    </div>
                    <div class="performer-stat">
                        <span class="performer-stat-label">Courses:</span>
                        <span class="performer-stat-value">${performer.coursesCompleted}</span>
                    </div>
                    <div class="performer-stat">
                        <span class="performer-stat-label">Streak:</span>
                        <span class="performer-stat-value">${performer.streak} days 🔥</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    
    // Others
    const others = topPerformers.slice(3);
    othersContainer.innerHTML = '<div class="other-performers">' + others.map(performer => `
        <div class="other-performer">
            <div class="performer-left">
                <span class="performer-number">#${performer.rank}</span>
                <img src="${performer.avatar}" alt="${performer.name}" class="small-avatar">
                <div class="performer-info">
                    <p>${performer.name}</p>
                    <p>${performer.coursesCompleted} courses completed</p>
                </div>
            </div>
            <div class="performer-right">
                <p>${performer.xp.toLocaleString()} XP</p>
                <p>${performer.streak} day streak</p>
            </div>
        </div>
    `).join('') + '</div>';
}

function renderContributors() {
    const container = document.getElementById('contributorsGrid');
    container.innerHTML = topContributors.map(contributor => `
        <div class="card contributor-card">
            <img src="${contributor.avatar}" alt="${contributor.name}" class="contributor-avatar">
            <h4 class="contributor-name">${contributor.name}</h4>
            <span class="contributor-badge">${contributor.badge}</span>
            <div class="contributor-number">${contributor.contributions}</div>
            <div class="contributor-type">${contributor.type}</div>
        </div>
    `).join('');
}

function renderDiscussions() {
    const container = document.getElementById('discussionsList');
    container.innerHTML = discussions.map(discussion => `
        <div class="discussion-item">
            <div class="discussion-header">
                <h4 class="discussion-title">${discussion.title}</h4>
                <span class="discussion-category">${discussion.category}</span>
            </div>
            <div class="discussion-meta">
                <div class="discussion-info">
                    <span>by ${discussion.author}</span>
                    <span class="discussion-stat">
                        <i class="fas fa-comment"></i>
                        ${discussion.replies} replies
                    </span>
                    <span class="discussion-stat">
                        <i class="fas fa-thumbs-up"></i>
                        ${discussion.likes} likes
                    </span>
                </div>
                <span>${discussion.time}</span>
            </div>
        </div>
    `).join('');
}

// Trending Skills
function initializeTrendingSkills() {
    renderTrendingSkills();
    renderAllSkills();
}

function renderTrendingSkills() {
    const container = document.getElementById('trendingGrid');
    const trending = trendingSkills.filter(s => s.trending).slice(0, 3);
    
    container.innerHTML = trending.map(skill => `
        <div class="skill-card">
            <div class="skill-card-header">
                <span class="trending-badge">Trending</span>
                <span class="growth-indicator">
                    <i class="fas fa-arrow-up"></i>
                    +${skill.growth}%
                </span>
            </div>
            <h4 class="skill-name">${skill.name}</h4>
            <p class="skill-description">${skill.description}</p>
            <div class="skill-stats">
                <div class="skill-stat-row">
                    <span class="skill-stat-label">Demand:</span>
                    <span class="skill-stat-value high">${skill.demand}</span>
                </div>
                <div class="skill-stat-row">
                    <span class="skill-stat-label">Avg Salary:</span>
                    <span class="skill-stat-value">${skill.avgSalary}</span>
                </div>
                <div class="skill-stat-row">
                    <span class="skill-stat-label">Learners:</span>
                    <span class="skill-stat-value">${(skill.learners / 1000).toFixed(0)}k</span>
                </div>
            </div>
            <button class="skill-btn">View ${skill.courses} Courses</button>
        </div>
    `).join('');
}

function renderAllSkills() {
    const container = document.getElementById('allSkillsList');
    container.innerHTML = '<div class="all-skills-list">' + trendingSkills.map((skill, idx) => {
        const progress = idx % 3 === 0 ? 0 : idx % 3 === 1 ? 45 : 78;
        return `
            <div class="all-skill-item">
                <div class="all-skill-header">
                    <div class="all-skill-title-container">
                        <div class="all-skill-title-row">
                            <h4 class="all-skill-name">${skill.name}</h4>
                            ${skill.trending ? '<span class="hot-badge"><i class="fas fa-star"></i> Hot</span>' : ''}
                            <span class="category-badge">${skill.category}</span>
                        </div>
                        <p class="all-skill-description">${skill.description}</p>
                        <div class="all-skill-stats-grid">
                            <div class="all-skill-stat">
                                <p>Growth</p>
                                <p style="color: #10b981;"><i class="fas fa-arrow-up"></i> +${skill.growth}%</p>
                            </div>
                            <div class="all-skill-stat">
                                <p>Demand</p>
                                <p>${skill.demand}</p>
                            </div>
                            <div class="all-skill-stat">
                                <p>Avg Salary</p>
                                <p>${skill.avgSalary}</p>
                            </div>
                            <div class="all-skill-stat">
                                <p>Courses</p>
                                <p>${skill.courses} available</p>
                            </div>
                        </div>
                        <div class="skill-progress-section">
                            <div class="skill-progress-header">
                                <span>Your Progress</span>
                                <span>${progress}%</span>
                            </div>
                            <div class="skill-progress-bar">
                                <div class="skill-progress-fill" style="width: ${progress}%"></div>
                            </div>
                        </div>
                    </div>
                    <button class="skill-btn">Start Learning</button>
                </div>
            </div>
        `;
    }).join('') + '</div>';
}
