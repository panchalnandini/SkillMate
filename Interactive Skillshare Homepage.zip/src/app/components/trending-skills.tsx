import { TrendingUp, ArrowUpRight, Star, Users, BookOpen } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';

interface Skill {
  name: string;
  category: string;
  growth: number;
  demand: string;
  avgSalary: string;
  learners: number;
  courses: number;
  description: string;
  trending: boolean;
}

const trendingSkills: Skill[] = [
  {
    name: "Artificial Intelligence & Machine Learning",
    category: "Technology",
    growth: 245,
    demand: "Very High",
    avgSalary: "$120k - $180k",
    learners: 125000,
    courses: 342,
    description: "AI and ML continue to dominate as companies integrate intelligent systems.",
    trending: true
  },
  {
    name: "Cloud Computing (AWS, Azure, GCP)",
    category: "Technology",
    growth: 198,
    demand: "Very High",
    avgSalary: "$110k - $160k",
    learners: 98000,
    courses: 287,
    description: "Cloud infrastructure skills are essential for modern software development.",
    trending: true
  },
  {
    name: "Cybersecurity",
    category: "Technology",
    growth: 187,
    demand: "Very High",
    avgSalary: "$100k - $150k",
    learners: 87000,
    courses: 234,
    description: "Growing threats drive massive demand for security professionals.",
    trending: true
  },
  {
    name: "Data Science & Analytics",
    category: "Technology",
    growth: 165,
    demand: "High",
    avgSalary: "$95k - $145k",
    learners: 112000,
    courses: 398,
    description: "Data-driven decision making is crucial across all industries.",
    trending: false
  },
  {
    name: "Full-Stack Development",
    category: "Technology",
    growth: 142,
    demand: "High",
    avgSalary: "$90k - $140k",
    learners: 156000,
    courses: 512,
    description: "Versatile developers who can handle both frontend and backend are in high demand.",
    trending: false
  },
  {
    name: "UI/UX Design",
    category: "Design",
    growth: 128,
    demand: "High",
    avgSalary: "$80k - $130k",
    learners: 78000,
    courses: 267,
    description: "User experience is a key differentiator for digital products.",
    trending: false
  },
  {
    name: "DevOps & CI/CD",
    category: "Technology",
    growth: 156,
    demand: "Very High",
    avgSalary: "$105k - $155k",
    learners: 65000,
    courses: 189,
    description: "Automation and continuous deployment are standard practices now.",
    trending: true
  },
  {
    name: "Mobile App Development",
    category: "Technology",
    growth: 118,
    demand: "Medium-High",
    avgSalary: "$85k - $135k",
    learners: 92000,
    courses: 345,
    description: "Mobile-first approach drives demand for iOS and Android developers.",
    trending: false
  },
  {
    name: "Blockchain & Web3",
    category: "Technology",
    growth: 215,
    demand: "Medium-High",
    avgSalary: "$100k - $170k",
    learners: 45000,
    courses: 156,
    description: "Emerging technology with growing adoption in finance and beyond.",
    trending: true
  },
  {
    name: "Digital Marketing & SEO",
    category: "Marketing",
    growth: 95,
    demand: "Medium-High",
    avgSalary: "$60k - $100k",
    learners: 134000,
    courses: 423,
    description: "Essential for business growth in the digital age.",
    trending: false
  }
];

export function TrendingSkills() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl mb-2">In-Demand Skills</h2>
        <p className="text-gray-400">Stay ahead with the most sought-after skills in the market</p>
      </div>

      {/* Market Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card className="p-6 bg-gradient-to-br from-green-600 to-green-700 border-0">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm mb-1">Market Growth</p>
              <p className="text-3xl">+34%</p>
              <p className="text-sm text-green-100 mt-1">vs last quarter</p>
            </div>
            <TrendingUp className="w-12 h-12 text-green-200" />
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-blue-600 to-blue-700 border-0">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm mb-1">Active Learners</p>
              <p className="text-3xl">1.2M+</p>
              <p className="text-sm text-blue-100 mt-1">across all skills</p>
            </div>
            <Users className="w-12 h-12 text-blue-200" />
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-purple-600 to-purple-700 border-0">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm mb-1">Available Courses</p>
              <p className="text-3xl">3,500+</p>
              <p className="text-sm text-purple-100 mt-1">curated for you</p>
            </div>
            <BookOpen className="w-12 h-12 text-purple-200" />
          </div>
        </Card>
      </div>

      {/* Top Trending */}
      <div className="mb-8">
        <h3 className="text-2xl mb-4 flex items-center gap-2">
          <TrendingUp className="w-6 h-6 text-orange-500" />
          Top Trending This Month
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {trendingSkills.filter(s => s.trending).slice(0, 3).map((skill, idx) => (
            <Card key={idx} className="p-6 bg-zinc-900 border-zinc-800 hover:border-blue-600 transition-colors">
              <div className="flex items-start justify-between mb-3">
                <Badge className="bg-orange-600">Trending</Badge>
                <div className="flex items-center gap-1 text-green-500">
                  <ArrowUpRight className="w-4 h-4" />
                  <span className="text-sm font-medium">+{skill.growth}%</span>
                </div>
              </div>
              <h4 className="text-xl mb-2">{skill.name}</h4>
              <p className="text-sm text-gray-400 mb-4">{skill.description}</p>
              <div className="space-y-2 text-sm mb-4">
                <div className="flex justify-between">
                  <span className="text-gray-400">Demand:</span>
                  <span className="text-green-400 font-medium">{skill.demand}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Avg Salary:</span>
                  <span className="font-medium">{skill.avgSalary}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Learners:</span>
                  <span className="font-medium">{(skill.learners / 1000).toFixed(0)}k</span>
                </div>
              </div>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                View {skill.courses} Courses
              </Button>
            </Card>
          ))}
        </div>
      </div>

      {/* All Skills */}
      <div>
        <h3 className="text-2xl mb-4">All In-Demand Skills</h3>
        <Card className="p-6 bg-zinc-900 border-zinc-800">
          <div className="space-y-4">
            {trendingSkills.map((skill, idx) => (
              <div 
                key={idx}
                className="p-4 rounded-lg border border-zinc-800 hover:border-zinc-700 hover:bg-zinc-800 transition-colors"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h4 className="text-lg">{skill.name}</h4>
                      {skill.trending && (
                        <Badge className="bg-orange-600 text-xs">
                          <Star className="w-3 h-3 mr-1 inline" />
                          Hot
                        </Badge>
                      )}
                      <Badge variant="outline" className="text-xs">{skill.category}</Badge>
                    </div>
                    <p className="text-sm text-gray-400 mb-3">{skill.description}</p>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500 mb-1">Growth</p>
                        <div className="flex items-center gap-1 text-green-500">
                          <ArrowUpRight className="w-4 h-4" />
                          <span className="font-medium">+{skill.growth}%</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-gray-500 mb-1">Demand</p>
                        <p className="font-medium">{skill.demand}</p>
                      </div>
                      <div>
                        <p className="text-gray-500 mb-1">Avg Salary</p>
                        <p className="font-medium">{skill.avgSalary}</p>
                      </div>
                      <div>
                        <p className="text-gray-500 mb-1">Courses</p>
                        <p className="font-medium">{skill.courses} available</p>
                      </div>
                    </div>

                    {/* Your Progress (mock data) */}
                    <div className="mt-3">
                      <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                        <span>Your Progress</span>
                        <span>{idx % 3 === 0 ? '0%' : idx % 3 === 1 ? '45%' : '78%'}</span>
                      </div>
                      <Progress value={idx % 3 === 0 ? 0 : idx % 3 === 1 ? 45 : 78} className="h-2" />
                    </div>
                  </div>

                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Start Learning
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Industry Insights */}
      <Card className="mt-8 p-6 bg-gradient-to-br from-indigo-600 to-indigo-700 border-0">
        <div className="text-center">
          <h3 className="text-2xl mb-2">💡 Industry Insights</h3>
          <p className="text-lg mb-4 text-indigo-100">
            Based on analysis from LinkedIn, Indeed, and Glassdoor job postings
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left">
            <div className="bg-white/10 rounded-lg p-4">
              <p className="text-3xl mb-2">85%</p>
              <p className="text-sm text-indigo-100">of tech jobs require cloud skills</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <p className="text-3xl mb-2">2.5x</p>
              <p className="text-sm text-indigo-100">salary increase with AI/ML expertise</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <p className="text-3xl mb-2">70%</p>
              <p className="text-sm text-indigo-100">of companies plan to hire cybersecurity experts</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
