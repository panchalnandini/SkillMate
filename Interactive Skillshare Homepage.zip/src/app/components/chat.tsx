import { useState } from 'react';
import { Send, Paperclip, Video, Phone, MoreVertical, Search, Calendar } from 'lucide-react';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';

interface Message {
  id: number;
  sender: string;
  content: string;
  timestamp: string;
  isMe: boolean;
}

interface Contact {
  id: number;
  name: string;
  avatar: string;
  lastMessage: string;
  timestamp: string;
  unread: number;
  online: boolean;
}

const contacts: Contact[] = [
  {
    id: 1,
    name: "Sarah Johnson",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    lastMessage: "Sure! Let's meet at 3 PM tomorrow",
    timestamp: "2m ago",
    unread: 2,
    online: true
  },
  {
    id: 2,
    name: "Marcus Chen",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    lastMessage: "Thanks for the Python tutorial!",
    timestamp: "1h ago",
    unread: 0,
    online: true
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    lastMessage: "Can you review my design?",
    timestamp: "3h ago",
    unread: 1,
    online: false
  },
  {
    id: 4,
    name: "Study Group: React Masters",
    avatar: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=100&h=100&fit=crop",
    lastMessage: "Alex: Great session today!",
    timestamp: "5h ago",
    unread: 5,
    online: false
  }
];

const initialMessages: Message[] = [
  {
    id: 1,
    sender: "Sarah Johnson",
    content: "Hey! I saw your profile and noticed we're both learning React. Want to collaborate on a project?",
    timestamp: "10:30 AM",
    isMe: false
  },
  {
    id: 2,
    sender: "Me",
    content: "Hi Sarah! That sounds great! I'm actually working on a portfolio site right now.",
    timestamp: "10:32 AM",
    isMe: true
  },
  {
    id: 3,
    sender: "Sarah Johnson",
    content: "Perfect! I'm trying to build a task management app. Maybe we can help each other?",
    timestamp: "10:35 AM",
    isMe: false
  },
  {
    id: 4,
    sender: "Me",
    content: "Absolutely! When would you like to meet?",
    timestamp: "10:36 AM",
    isMe: true
  },
  {
    id: 5,
    sender: "Sarah Johnson",
    content: "Sure! Let's meet at 3 PM tomorrow",
    timestamp: "10:38 AM",
    isMe: false
  }
];

export function Chat() {
  const [selectedContact, setSelectedContact] = useState(contacts[0]);
  const [messages, setMessages] = useState(initialMessages);
  const [newMessage, setNewMessage] = useState('');

  const handleSend = () => {
    if (newMessage.trim()) {
      const message: Message = {
        id: messages.length + 1,
        sender: "Me",
        content: newMessage,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isMe: true
      };
      setMessages([...messages, message]);
      setNewMessage('');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-6">
        <h2 className="text-3xl mb-2">Messages</h2>
        <p className="text-gray-400">Connect and collaborate with your peers</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-[700px]">
        {/* Contacts List */}
        <Card className="bg-zinc-900 border-zinc-800 p-4 overflow-hidden flex flex-col">
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input 
                placeholder="Search messages..." 
                className="pl-10 bg-zinc-800 border-zinc-700"
              />
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto space-y-2">
            {contacts.map((contact) => (
              <div
                key={contact.id}
                onClick={() => setSelectedContact(contact)}
                className={`p-3 rounded-lg cursor-pointer transition-colors ${
                  selectedContact.id === contact.id 
                    ? 'bg-blue-600/20 border border-blue-600' 
                    : 'hover:bg-zinc-800'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="relative">
                    <Avatar>
                      <AvatarImage src={contact.avatar} />
                      <AvatarFallback>{contact.name[0]}</AvatarFallback>
                    </Avatar>
                    {contact.online && (
                      <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-zinc-900"></div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start mb-1">
                      <p className="font-medium truncate">{contact.name}</p>
                      <span className="text-xs text-gray-400">{contact.timestamp}</span>
                    </div>
                    <p className="text-sm text-gray-400 truncate">{contact.lastMessage}</p>
                  </div>
                  {contact.unread > 0 && (
                    <Badge className="bg-blue-600 text-white">{contact.unread}</Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Chat Window */}
        <Card className="lg:col-span-2 bg-zinc-900 border-zinc-800 flex flex-col overflow-hidden">
          {/* Chat Header */}
          <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Avatar>
                  <AvatarImage src={selectedContact.avatar} />
                  <AvatarFallback>{selectedContact.name[0]}</AvatarFallback>
                </Avatar>
                {selectedContact.online && (
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-zinc-900"></div>
                )}
              </div>
              <div>
                <p className="font-medium">{selectedContact.name}</p>
                <p className="text-sm text-gray-400">
                  {selectedContact.online ? 'Online' : 'Offline'}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" size="icon">
                <Phone className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon">
                <Video className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon">
                <Calendar className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon">
                <MoreVertical className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.isMe ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[70%] rounded-lg p-3 ${
                    message.isMe
                      ? 'bg-blue-600 text-white'
                      : 'bg-zinc-800 text-gray-100'
                  }`}
                >
                  {!message.isMe && (
                    <p className="text-xs text-gray-400 mb-1">{message.sender}</p>
                  )}
                  <p>{message.content}</p>
                  <p className={`text-xs mt-1 ${message.isMe ? 'text-blue-100' : 'text-gray-500'}`}>
                    {message.timestamp}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Message Input */}
          <div className="p-4 border-t border-zinc-800">
            <div className="flex gap-2">
              <Button variant="ghost" size="icon">
                <Paperclip className="w-5 h-5" />
              </Button>
              <Input
                placeholder="Type your message..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                className="flex-1 bg-zinc-800 border-zinc-700"
              />
              <Button onClick={handleSend} className="bg-blue-600 hover:bg-blue-700">
                <Send className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
