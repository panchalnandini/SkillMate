import { Trophy, Target, Flame, BookOpen, Award, TrendingUp } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

interface SkillProgress {
  name: string;
  progress: number;
  xp: number;
  totalXp: number;
}

const skillsProgress: SkillProgress[] = [
  { name: "React Development", progress: 75, xp: 7500, totalXp: 10000 },
  { name: "Python Programming", progress: 45, xp: 4500, totalXp: 10000 },
  { name: "UI/UX Design", progress: 60, xp: 6000, totalXp: 10000 },
  { name: "Data Science", progress: 30, xp: 3000, totalXp: 10000 },
];

const achievements = [
  { name: "Fast Learner", description: "Complete 5 courses in a week", earned: true },
  { name: "Community Helper", description: "Help 10 peers", earned: true },
  { name: "Streak Master", description: "7-day learning streak", earned: true },
  { name: "Skill Expert", description: "Master 3 skills", earned: false },
];

const recentActivity = [
  { course: "Advanced React Patterns", progress: 85, date: "Today" },
  { course: "Python for Data Analysis", progress: 40, date: "Yesterday" },
  { course: "Figma Masterclass", progress: 65, date: "2 days ago" },
];

export function Dashboard() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl mb-2">Your Learning Dashboard</h2>
        <p className="text-gray-400">Track your progress and achievements</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card className="p-6 bg-gradient-to-br from-blue-600 to-blue-700 border-0">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm">Total XP</p>
              <p className="text-3xl mt-1">21,000</p>
            </div>
            <Trophy className="w-10 h-10 text-blue-200" />
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-green-600 to-green-700 border-0">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm">Courses Completed</p>
              <p className="text-3xl mt-1">12</p>
            </div>
            <BookOpen className="w-10 h-10 text-green-200" />
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-orange-600 to-orange-700 border-0">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-100 text-sm">Current Streak</p>
              <p className="text-3xl mt-1">7 days</p>
            </div>
            <Flame className="w-10 h-10 text-orange-200" />
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-purple-600 to-purple-700 border-0">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm">Skills Mastered</p>
              <p className="text-3xl mt-1">5</p>
            </div>
            <Target className="w-10 h-10 text-purple-200" />
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Skills Progress */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-6 bg-zinc-900 border-zinc-800">
            <h3 className="text-xl mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-500" />
              Skills Progress
            </h3>
            <div className="space-y-6">
              {skillsProgress.map((skill, idx) => (
                <div key={idx}>
                  <div className="flex justify-between mb-2">
                    <span>{skill.name}</span>
                    <span className="text-sm text-gray-400">
                      {skill.xp.toLocaleString()} / {skill.totalXp.toLocaleString()} XP
                    </span>
                  </div>
                  <Progress value={skill.progress} className="h-3" />
                  <div className="text-xs text-gray-500 mt-1">{skill.progress}% Complete</div>
                </div>
              ))}
            </div>
          </Card>

          {/* Recent Activity */}
          <Card className="p-6 bg-zinc-900 border-zinc-800">
            <h3 className="text-xl mb-4">Recent Activity</h3>
            <div className="space-y-4">
              {recentActivity.map((activity, idx) => (
                <div key={idx} className="flex items-center justify-between pb-4 border-b border-zinc-800 last:border-0">
                  <div className="flex-1">
                    <p className="mb-1">{activity.course}</p>
                    <div className="flex items-center gap-3">
                      <Progress value={activity.progress} className="h-2 flex-1 max-w-xs" />
                      <span className="text-sm text-gray-400">{activity.progress}%</span>
                    </div>
                  </div>
                  <span className="text-sm text-gray-500 ml-4">{activity.date}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Achievements */}
        <div>
          <Card className="p-6 bg-zinc-900 border-zinc-800">
            <h3 className="text-xl mb-4 flex items-center gap-2">
              <Award className="w-5 h-5 text-yellow-500" />
              Achievements
            </h3>
            <div className="space-y-3">
              {achievements.map((achievement, idx) => (
                <div 
                  key={idx}
                  className={`p-4 rounded-lg border ${
                    achievement.earned 
                      ? 'bg-yellow-500/10 border-yellow-500/30' 
                      : 'bg-zinc-800 border-zinc-700 opacity-60'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <Award className={`w-5 h-5 mt-0.5 ${achievement.earned ? 'text-yellow-500' : 'text-gray-500'}`} />
                    <div className="flex-1">
                      <p className="font-medium mb-1">{achievement.name}</p>
                      <p className="text-sm text-gray-400">{achievement.description}</p>
                    </div>
                    {achievement.earned && (
                      <Badge className="bg-yellow-500 text-black">Earned</Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Weekly Goal */}
          <Card className="p-6 bg-gradient-to-br from-indigo-600 to-indigo-700 border-0 mt-4">
            <h3 className="text-xl mb-4">Weekly Goal</h3>
            <div className="text-center py-4">
              <div className="text-5xl mb-2">🎯</div>
              <p className="text-lg mb-2">Complete 3 Courses</p>
              <Progress value={66} className="h-3 mb-2" />
              <p className="text-sm text-indigo-100">2 of 3 completed</p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
