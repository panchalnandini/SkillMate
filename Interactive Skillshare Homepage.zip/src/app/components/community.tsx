import { Trophy, Medal, Star, TrendingUp, MessageSquare, ThumbsUp } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Button } from './ui/button';

interface TopPerformer {
  rank: number;
  name: string;
  avatar: string;
  xp: number;
  coursesCompleted: number;
  streak: number;
}

interface Contributor {
  name: string;
  avatar: string;
  contributions: number;
  type: string;
  badge: string;
}

const topPerformers: TopPerformer[] = [
  {
    rank: 1,
    name: "Alex Kumar",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    xp: 45000,
    coursesCompleted: 25,
    streak: 30
  },
  {
    rank: 2,
    name: "Sarah Johnson",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    xp: 42000,
    coursesCompleted: 23,
    streak: 28
  },
  {
    rank: 3,
    name: "Marcus Chen",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    xp: 38000,
    coursesCompleted: 21,
    streak: 25
  },
  {
    rank: 4,
    name: "Emily Rodriguez",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    xp: 35000,
    coursesCompleted: 19,
    streak: 22
  },
  {
    rank: 5,
    name: "Jessica Park",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop",
    xp: 32000,
    coursesCompleted: 18,
    streak: 20
  }
];

const topContributors: Contributor[] = [
  {
    name: "David Lee",
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop",
    contributions: 127,
    type: "Helpful Answers",
    badge: "Expert Helper"
  },
  {
    name: "Lisa Wang",
    avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop",
    contributions: 98,
    type: "Resources Shared",
    badge: "Resource Master"
  },
  {
    name: "James Miller",
    avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100&h=100&fit=crop",
    contributions: 85,
    type: "Helpful Answers",
    badge: "Community Star"
  }
];

const discussions = [
  {
    title: "Best practices for React state management?",
    author: "Sarah Johnson",
    replies: 24,
    likes: 45,
    category: "React",
    time: "2h ago"
  },
  {
    title: "Python vs JavaScript for beginners",
    author: "Marcus Chen",
    replies: 18,
    likes: 32,
    category: "General",
    time: "5h ago"
  },
  {
    title: "How to design better user interfaces?",
    author: "Emily Rodriguez",
    replies: 15,
    likes: 28,
    category: "Design",
    time: "1d ago"
  }
];

export function Community() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl mb-2">Community</h2>
        <p className="text-gray-400">Celebrate achievements and connect with peers</p>
      </div>

      {/* Weekly Spotlight */}
      <div className="mb-8">
        <h3 className="text-2xl mb-4 flex items-center gap-2">
          <Trophy className="w-6 h-6 text-yellow-500" />
          Weekly Top Performers
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          {topPerformers.slice(0, 3).map((performer) => (
            <Card 
              key={performer.rank}
              className={`p-6 border-2 ${
                performer.rank === 1 
                  ? 'bg-gradient-to-br from-yellow-600/20 to-yellow-700/20 border-yellow-500'
                  : performer.rank === 2
                  ? 'bg-gradient-to-br from-gray-400/20 to-gray-500/20 border-gray-400'
                  : 'bg-gradient-to-br from-orange-600/20 to-orange-700/20 border-orange-600'
              }`}
            >
              <div className="text-center">
                <div className="relative inline-block mb-4">
                  <Avatar className="w-24 h-24">
                    <AvatarImage src={performer.avatar} />
                    <AvatarFallback>{performer.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className={`absolute -top-2 -right-2 w-10 h-10 rounded-full flex items-center justify-center ${
                    performer.rank === 1 ? 'bg-yellow-500' :
                    performer.rank === 2 ? 'bg-gray-400' :
                    'bg-orange-600'
                  }`}>
                    {performer.rank === 1 ? <Trophy className="w-5 h-5 text-white" /> :
                     performer.rank === 2 ? <Medal className="w-5 h-5 text-white" /> :
                     <Medal className="w-5 h-5 text-white" />}
                  </div>
                </div>
                <h4 className="text-xl mb-2">{performer.name}</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Total XP:</span>
                    <span className="font-medium">{performer.xp.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Courses:</span>
                    <span className="font-medium">{performer.coursesCompleted}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Streak:</span>
                    <span className="font-medium">{performer.streak} days 🔥</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <Card className="p-4 bg-zinc-900 border-zinc-800">
          <div className="space-y-2">
            {topPerformers.slice(3).map((performer) => (
              <div 
                key={performer.rank}
                className="flex items-center justify-between p-3 rounded-lg bg-zinc-800 hover:bg-zinc-750 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <span className="text-2xl font-bold text-gray-500 w-8">#{performer.rank}</span>
                  <Avatar>
                    <AvatarImage src={performer.avatar} />
                    <AvatarFallback>{performer.name[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{performer.name}</p>
                    <p className="text-sm text-gray-400">{performer.coursesCompleted} courses completed</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium">{performer.xp.toLocaleString()} XP</p>
                  <p className="text-sm text-gray-400">{performer.streak} day streak</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Top Contributors */}
      <div className="mb-8">
        <h3 className="text-2xl mb-4 flex items-center gap-2">
          <Star className="w-6 h-6 text-blue-500" />
          Top Contributors
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {topContributors.map((contributor, idx) => (
            <Card key={idx} className="p-6 bg-zinc-900 border-zinc-800">
              <div className="text-center">
                <Avatar className="w-20 h-20 mx-auto mb-4">
                  <AvatarImage src={contributor.avatar} />
                  <AvatarFallback>{contributor.name[0]}</AvatarFallback>
                </Avatar>
                <h4 className="mb-1">{contributor.name}</h4>
                <Badge className="mb-3 bg-blue-600">{contributor.badge}</Badge>
                <div className="text-3xl font-bold text-blue-500 mb-1">
                  {contributor.contributions}
                </div>
                <p className="text-sm text-gray-400">{contributor.type}</p>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Discussion Board */}
      <div>
        <h3 className="text-2xl mb-4 flex items-center gap-2">
          <MessageSquare className="w-6 h-6 text-green-500" />
          Trending Discussions
        </h3>
        
        <Card className="p-6 bg-zinc-900 border-zinc-800">
          <div className="space-y-4">
            {discussions.map((discussion, idx) => (
              <div 
                key={idx}
                className="p-4 rounded-lg border border-zinc-800 hover:border-zinc-700 hover:bg-zinc-800 transition-colors cursor-pointer"
              >
                <div className="flex items-start justify-between mb-2">
                  <h4 className="text-lg flex-1">{discussion.title}</h4>
                  <Badge variant="outline" className="ml-4">{discussion.category}</Badge>
                </div>
                <div className="flex items-center justify-between text-sm text-gray-400">
                  <div className="flex items-center gap-4">
                    <span>by {discussion.author}</span>
                    <span className="flex items-center gap-1">
                      <MessageSquare className="w-4 h-4" />
                      {discussion.replies} replies
                    </span>
                    <span className="flex items-center gap-1">
                      <ThumbsUp className="w-4 h-4" />
                      {discussion.likes} likes
                    </span>
                  </div>
                  <span>{discussion.time}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 text-center">
            <Button variant="outline" className="w-full">View All Discussions</Button>
          </div>
        </Card>
      </div>

      {/* Challenge of the Week */}
      <Card className="mt-8 p-6 bg-gradient-to-br from-purple-600 to-purple-700 border-0">
        <div className="text-center">
          <h3 className="text-2xl mb-2">🏆 Challenge of the Week</h3>
          <p className="text-lg mb-4">Build a Weather App using React and an API</p>
          <div className="flex items-center justify-center gap-6 mb-4">
            <div>
              <div className="text-3xl font-bold">127</div>
              <div className="text-sm text-purple-100">Participants</div>
            </div>
            <div>
              <div className="text-3xl font-bold">3</div>
              <div className="text-sm text-purple-100">Days Left</div>
            </div>
          </div>
          <Button className="bg-white text-purple-700 hover:bg-purple-100">
            Join Challenge
          </Button>
        </div>
      </Card>
    </div>
  );
}
