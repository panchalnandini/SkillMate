import { useState } from 'react';
import { ChevronLeft, ChevronRight, Clock, Users, Video, MapPin } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface Meeting {
  id: number;
  title: string;
  date: string;
  time: string;
  duration: string;
  type: 'video' | 'inPerson';
  attendees: string[];
  color: string;
  location?: string;
}

const meetings: Meeting[] = [
  {
    id: 1,
    title: "React Study Session with Sarah",
    date: "2026-01-11",
    time: "15:00",
    duration: "1 hour",
    type: "video",
    attendees: ["Sarah Johnson"],
    color: "blue"
  },
  {
    id: 2,
    title: "Python Workshop",
    date: "2026-01-12",
    time: "14:00",
    duration: "2 hours",
    type: "video",
    attendees: ["Marcus Chen", "Emily Rodriguez"],
    color: "green"
  },
  {
    id: 3,
    title: "Design Review",
    date: "2026-01-13",
    time: "10:00",
    duration: "30 min",
    type: "video",
    attendees: ["Emily Rodriguez"],
    color: "purple"
  },
  {
    id: 4,
    title: "Community Meetup",
    date: "2026-01-15",
    time: "18:00",
    duration: "2 hours",
    type: "inPerson",
    attendees: ["Study Group"],
    location: "Coffee House, Main St",
    color: "orange"
  }
];

const daysInMonth = 31;
const firstDayOfMonth = 3; // Wednesday (0 = Sunday)

export function CalendarView() {
  const [currentMonth] = useState("January 2026");
  const [selectedDate, setSelectedDate] = useState(11);

  const getMeetingsForDate = (day: number) => {
    const date = `2026-01-${String(day).padStart(2, '0')}`;
    return meetings.filter(m => m.date === date);
  };

  const todaysMeetings = getMeetingsForDate(selectedDate);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-6">
        <h2 className="text-3xl mb-2">Calendar</h2>
        <p className="text-gray-400">Manage your study sessions and meetings</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar */}
        <Card className="lg:col-span-2 p-6 bg-zinc-900 border-zinc-800">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl">{currentMonth}</h3>
            <div className="flex gap-2">
              <Button variant="outline" size="icon">
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon">
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="text-center text-sm font-medium text-gray-400 py-2">
                {day}
              </div>
            ))}

            {[...Array(firstDayOfMonth)].map((_, i) => (
              <div key={`empty-${i}`} className="aspect-square" />
            ))}

            {[...Array(daysInMonth)].map((_, i) => {
              const day = i + 1;
              const dayMeetings = getMeetingsForDate(day);
              const isToday = day === 10;
              const isSelected = day === selectedDate;

              return (
                <div
                  key={day}
                  onClick={() => setSelectedDate(day)}
                  className={`aspect-square p-2 rounded-lg cursor-pointer transition-colors relative ${
                    isToday ? 'bg-blue-600/20 border-2 border-blue-600' :
                    isSelected ? 'bg-zinc-700' :
                    'hover:bg-zinc-800'
                  }`}
                >
                  <div className="text-sm">{day}</div>
                  {dayMeetings.length > 0 && (
                    <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 flex gap-1">
                      {dayMeetings.slice(0, 3).map((meeting, idx) => (
                        <div
                          key={idx}
                          className={`w-1.5 h-1.5 rounded-full bg-${meeting.color}-500`}
                          style={{ backgroundColor: meeting.color === 'blue' ? '#3b82f6' : meeting.color === 'green' ? '#10b981' : meeting.color === 'purple' ? '#a855f7' : '#f97316' }}
                        />
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </Card>

        {/* Upcoming Meetings */}
        <Card className="p-6 bg-zinc-900 border-zinc-800">
          <h3 className="text-xl mb-4">
            Meetings for January {selectedDate}
          </h3>
          
          {todaysMeetings.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <p>No meetings scheduled</p>
            </div>
          ) : (
            <div className="space-y-4">
              {todaysMeetings.map((meeting) => (
                <div
                  key={meeting.id}
                  className="p-4 rounded-lg bg-zinc-800 border border-zinc-700 hover:border-zinc-600 transition-colors"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-medium">{meeting.title}</h4>
                    <Badge 
                      className={`${
                        meeting.color === 'blue' ? 'bg-blue-600' :
                        meeting.color === 'green' ? 'bg-green-600' :
                        meeting.color === 'purple' ? 'bg-purple-600' :
                        'bg-orange-600'
                      }`}
                    >
                      {meeting.type === 'video' ? 'Video' : 'In Person'}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2 text-sm text-gray-400">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      {meeting.time} • {meeting.duration}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      {meeting.attendees.join(', ')}
                    </div>
                    
                    {meeting.type === 'video' ? (
                      <div className="flex items-center gap-2">
                        <Video className="w-4 h-4" />
                        Video Call
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        {meeting.location}
                      </div>
                    )}
                  </div>

                  <div className="flex gap-2 mt-4">
                    <Button size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700">
                      Join Meeting
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1">
                      Reschedule
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      {/* All Upcoming Meetings */}
      <Card className="mt-6 p-6 bg-zinc-900 border-zinc-800">
        <h3 className="text-xl mb-4">All Upcoming Meetings</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {meetings.map((meeting) => (
            <div
              key={meeting.id}
              className="p-4 rounded-lg bg-zinc-800 border-l-4 hover:bg-zinc-750 transition-colors"
              style={{ 
                borderLeftColor: 
                  meeting.color === 'blue' ? '#3b82f6' : 
                  meeting.color === 'green' ? '#10b981' : 
                  meeting.color === 'purple' ? '#a855f7' : 
                  '#f97316' 
              }}
            >
              <p className="font-medium mb-2">{meeting.title}</p>
              <div className="text-sm text-gray-400 space-y-1">
                <p>{new Date(meeting.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</p>
                <p>{meeting.time} • {meeting.duration}</p>
                <p className="flex items-center gap-1">
                  {meeting.type === 'video' ? <Video className="w-3 h-3" /> : <MapPin className="w-3 h-3" />}
                  {meeting.type === 'video' ? 'Video Call' : 'In Person'}
                </p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
