import { useState } from 'react';
import { X, Heart, Briefcase, MapPin, Award } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';

interface Profile {
  id: number;
  name: string;
  age: number;
  location: string;
  skills: string[];
  learningGoals: string[];
  bio: string;
  image: string;
  completedCourses: number;
  level: string;
}

const mockProfiles: Profile[] = [
  {
    id: 1,
    name: "Sarah Johnson",
    age: 24,
    location: "San Francisco, CA",
    skills: ["React", "TypeScript", "UI Design"],
    learningGoals: ["Backend Development", "Python", "Data Science"],
    bio: "Frontend developer looking to expand into full-stack. Love building beautiful interfaces!",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=500&fit=crop",
    completedCourses: 12,
    level: "Intermediate"
  },
  {
    id: 2,
    name: "Marcus Chen",
    age: 28,
    location: "New York, NY",
    skills: ["Python", "Machine Learning", "Data Analysis"],
    learningGoals: ["Web Development", "React", "TypeScript"],
    bio: "Data scientist eager to learn web development to build ML applications.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=500&fit=crop",
    completedCourses: 18,
    level: "Advanced"
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    age: 22,
    location: "Austin, TX",
    skills: ["UX Design", "Figma", "Adobe XD"],
    learningGoals: ["Frontend Development", "CSS", "Animation"],
    bio: "Designer wanting to code my own designs. Passionate about user experience!",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=500&fit=crop",
    completedCourses: 8,
    level: "Beginner"
  },
  {
    id: 4,
    name: "Alex Kumar",
    age: 26,
    location: "Seattle, WA",
    skills: ["Node.js", "MongoDB", "Express"],
    learningGoals: ["DevOps", "AWS", "Docker"],
    bio: "Backend engineer looking to master cloud infrastructure and deployment.",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=500&fit=crop",
    completedCourses: 15,
    level: "Intermediate"
  },
  {
    id: 5,
    name: "Jessica Park",
    age: 25,
    location: "Boston, MA",
    skills: ["Digital Marketing", "SEO", "Content Strategy"],
    learningGoals: ["Web Analytics", "Python", "Automation"],
    bio: "Marketing professional learning to automate workflows and analyze data.",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=500&fit=crop",
    completedCourses: 10,
    level: "Intermediate"
  }
];

export function Matchmaking() {
  const [profiles, setProfiles] = useState(mockProfiles);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [swipeDirection, setSwipeDirection] = useState<'left' | 'right' | null>(null);

  const handleSwipe = (direction: 'left' | 'right') => {
    setSwipeDirection(direction);
    setTimeout(() => {
      if (currentIndex < profiles.length - 1) {
        setCurrentIndex(currentIndex + 1);
      } else {
        setCurrentIndex(0); // Loop back
      }
      setSwipeDirection(null);
    }, 300);
  };

  const currentProfile = profiles[currentIndex];

  return (
    <div className="max-w-md mx-auto px-4 py-8">
      <div className="text-center mb-6">
        <h2 className="text-3xl mb-2">Find Your Learning Partner</h2>
        <p className="text-gray-400">Swipe right to connect, left to skip</p>
      </div>

      <div className="relative h-[600px] flex items-center justify-center">
        <AnimatePresence mode="wait">
          {currentProfile && (
            <motion.div
              key={currentProfile.id}
              initial={{ scale: 0.8, opacity: 0, rotateY: -10 }}
              animate={{ 
                scale: 1, 
                opacity: 1, 
                rotateY: 0,
                x: swipeDirection === 'left' ? -500 : swipeDirection === 'right' ? 500 : 0,
                rotate: swipeDirection === 'left' ? -20 : swipeDirection === 'right' ? 20 : 0
              }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="absolute w-full"
            >
              <Card className="overflow-hidden bg-gradient-to-br from-zinc-900 to-zinc-800 border-zinc-700">
                <div className="relative">
                  <img 
                    src={currentProfile.image} 
                    alt={currentProfile.name}
                    className="w-full h-80 object-cover"
                  />
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-blue-600 text-white">{currentProfile.level}</Badge>
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  <div>
                    <h3 className="text-2xl mb-1">{currentProfile.name}, {currentProfile.age}</h3>
                    <div className="flex items-center gap-2 text-gray-400 text-sm">
                      <MapPin className="w-4 h-4" />
                      {currentProfile.location}
                    </div>
                  </div>

                  <p className="text-gray-300">{currentProfile.bio}</p>

                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Briefcase className="w-4 h-4 text-blue-500" />
                      <span className="text-sm">Current Skills</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {currentProfile.skills.map((skill, idx) => (
                        <Badge key={idx} variant="secondary" className="bg-zinc-700">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Award className="w-4 h-4 text-green-500" />
                      <span className="text-sm">Learning Goals</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {currentProfile.learningGoals.map((goal, idx) => (
                        <Badge key={idx} variant="outline" className="border-blue-500 text-blue-400">
                          {goal}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="text-sm text-gray-400">
                    {currentProfile.completedCourses} courses completed
                  </div>
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="flex justify-center gap-6 mt-8">
        <Button
          size="lg"
          variant="outline"
          className="rounded-full w-16 h-16 border-red-500 hover:bg-red-500/20"
          onClick={() => handleSwipe('left')}
        >
          <X className="w-8 h-8 text-red-500" />
        </Button>
        <Button
          size="lg"
          className="rounded-full w-16 h-16 bg-green-600 hover:bg-green-700"
          onClick={() => handleSwipe('right')}
        >
          <Heart className="w-8 h-8" />
        </Button>
      </div>

      <div className="text-center mt-6 text-sm text-gray-400">
        Profile {currentIndex + 1} of {profiles.length}
      </div>
    </div>
  );
}
