import { useState } from 'react';
import { Home, LayoutDashboard, MessageSquare, Calendar, Users, TrendingUp, Menu, X } from 'lucide-react';
import { Button } from './components/ui/button';
import { Matchmaking } from './components/matchmaking';
import { Dashboard } from './components/dashboard';
import { Chat } from './components/chat';
import { CalendarView } from './components/calendar-view';
import { Community } from './components/community';
import { TrendingSkills } from './components/trending-skills';

type Section = 'home' | 'dashboard' | 'chat' | 'calendar' | 'community' | 'skills';

export default function App() {
  const [currentSection, setCurrentSection] = useState<Section>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigation = [
    { id: 'home' as Section, name: 'Home', icon: Home },
    { id: 'dashboard' as Section, name: 'Dashboard', icon: LayoutDashboard },
    { id: 'chat' as Section, name: 'Chat', icon: MessageSquare },
    { id: 'calendar' as Section, name: 'Calendar', icon: Calendar },
    { id: 'community' as Section, name: 'Community', icon: Users },
    { id: 'skills' as Section, name: 'Trending Skills', icon: TrendingUp },
  ];

  const renderSection = () => {
    switch (currentSection) {
      case 'home':
        return <Matchmaking />;
      case 'dashboard':
        return <Dashboard />;
      case 'chat':
        return <Chat />;
      case 'calendar':
        return <CalendarView />;
      case 'community':
        return <Community />;
      case 'skills':
        return <TrendingSkills />;
      default:
        return <Matchmaking />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 text-white">
      {/* Top Navigation Bar */}
      <nav className="sticky top-0 z-50 bg-zinc-950/80 backdrop-blur-lg border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <span className="text-xl font-bold">S</span>
                </div>
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-zinc-950"></div>
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
                  SkillSwap
                </h1>
                <p className="text-xs text-gray-400 hidden sm:block">Learn Together, Grow Together</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-2">
              {navigation.map((item) => {
                const Icon = item.icon;
                return (
                  <Button
                    key={item.id}
                    variant={currentSection === item.id ? 'default' : 'ghost'}
                    onClick={() => setCurrentSection(item.id)}
                    className={`gap-2 ${
                      currentSection === item.id 
                        ? 'bg-blue-600 hover:bg-blue-700' 
                        : 'hover:bg-zinc-800'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {item.name}
                  </Button>
                );
              })}
            </div>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>

            {/* Join Waitlist Button (Desktop) */}
            <Button className="hidden lg:block bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
              Join Waitlist
            </Button>
          </div>

          {/* Mobile Navigation Menu */}
          {mobileMenuOpen && (
            <div className="lg:hidden py-4 space-y-2 border-t border-zinc-800">
              {navigation.map((item) => {
                const Icon = item.icon;
                return (
                  <Button
                    key={item.id}
                    variant={currentSection === item.id ? 'default' : 'ghost'}
                    onClick={() => {
                      setCurrentSection(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full justify-start gap-2 ${
                      currentSection === item.id 
                        ? 'bg-blue-600 hover:bg-blue-700' 
                        : 'hover:bg-zinc-800'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {item.name}
                  </Button>
                );
              })}
            </div>
          )}
        </div>
      </nav>

      {/* Main Content */}
      <main className="pb-12">
        {renderSection()}
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800 bg-zinc-950/50">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-bold mb-4">About SkillSwap</h3>
              <p className="text-sm text-gray-400">
                Connect with learners, share skills, and grow together in a collaborative learning environment.
              </p>
            </div>
            <div>
              <h3 className="font-bold mb-4">Platform</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li className="hover:text-white cursor-pointer">How it works</li>
                <li className="hover:text-white cursor-pointer">Benefits</li>
                <li className="hover:text-white cursor-pointer">Success Stories</li>
                <li className="hover:text-white cursor-pointer">Pricing</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4">Resources</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li className="hover:text-white cursor-pointer">Blog</li>
                <li className="hover:text-white cursor-pointer">Guides</li>
                <li className="hover:text-white cursor-pointer">Community</li>
                <li className="hover:text-white cursor-pointer">Support</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4">Connect</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li className="hover:text-white cursor-pointer">Twitter</li>
                <li className="hover:text-white cursor-pointer">LinkedIn</li>
                <li className="hover:text-white cursor-pointer">Discord</li>
                <li className="hover:text-white cursor-pointer">Contact Us</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-zinc-800 text-center text-sm text-gray-400">
            <p>© 2026 SkillSwap. Launching May 2025. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
